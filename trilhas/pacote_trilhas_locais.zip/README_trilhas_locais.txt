Arquivos gerados:
- index_trilhas_locais.html -> versão do HTML apontando para arquivos locais na pasta trilhas/
- baixar_trilhas.ps1 -> script PowerShell para baixar os MP3 originais do MyInstants para a pasta trilhas/
- trilhas/manifesto_trilhas.json -> relação entre nome do arquivo local e URL original

Como usar:
1. Coloque o HTML e a pasta trilhas no mesmo diretório.
2. Execute o script baixar_trilhas.ps1 no Windows PowerShell para baixar os MP3.
3. Abra index_trilhas_locais.html.
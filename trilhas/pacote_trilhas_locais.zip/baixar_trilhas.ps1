$ErrorActionPreference = 'Stop'
$destino = Join-Path $PSScriptRoot 'trilhas'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
$arquivos = @(
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/exemplo.mp3'; Arquivo = 'exemplo.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/piao-do-bau-com-musica.mp3'; Arquivo = 'piao-do-bau-com-musica.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/certa-resposta-show-do-milhao.mp3'; Arquivo = 'certa-resposta-show-do-milhao.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/errou-show-do-milhao.mp3'; Arquivo = 'errou-show-do-milhao.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/ninguem-acertou.mp3'; Arquivo = 'ninguem-acertou.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/lost-a-life-game-over-sound-effect-8-bits.mp3'; Arquivo = 'lost-a-life-game-over-sound-effect-8-bits.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/errou-nadanada.mp3'; Arquivo = 'errou-nadanada.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/plateia.mp3'; Arquivo = 'plateia.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/georges-bizet-carmen-overture.mp3'; Arquivo = 'georges-bizet-carmen-overture.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/ele-fezz-de-novo-incansavel.mp3'; Arquivo = 'ele-fezz-de-novo-incansavel.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/irra-ratinho.mp3'; Arquivo = 'irra-ratinho.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/pare.mp3'; Arquivo = 'pare.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/que-isso-fi-faro.mp3'; Arquivo = 'que-isso-fi-faro.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/uepa_d0qhZxO.mp3'; Arquivo = 'uepa_d0qhZxO.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/tf_nemesis.mp3'; Arquivo = 'tf_nemesis.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/bongo-feet.mp3'; Arquivo = 'bongo-feet.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/aplausos-eeee.mp3'; Arquivo = 'aplausos-eeee.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/surpresaaaaaaa.mp3'; Arquivo = 'surpresaaaaaaa.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/james_brown_-_i_got_you_i_feel_good-1-i-got-you-i-feel-goodtrack-1.mp3'; Arquivo = 'james_brown_-_i_got_you_i_feel_good-1-i-got-you-i-feel-goodtrack-1.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/sound-baord-spongebob.mp3'; Arquivo = 'sound-baord-spongebob.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/vinheta_gol_do_brasil_1994_.mp3'; Arquivo = 'vinheta_gol_do_brasil_1994_.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/ah-agora-eu-entendi-agora-eu-saquei_Hocs3Q4.mp3'; Arquivo = 'ah-agora-eu-entendi-agora-eu-saquei_Hocs3Q4.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/senna-theme.mp3'; Arquivo = 'senna-theme.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/roda-roda-jequiti-tempo-10-segundos.mp3'; Arquivo = 'roda-roda-jequiti-tempo-10-segundos.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/sirene-alerta-alarme-bbb.mp3'; Arquivo = 'sirene-alerta-alarme-bbb.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/pergunta-silvio-santos.mp3'; Arquivo = 'pergunta-silvio-santos.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/y2mate_kKZFjgX.mp3'; Arquivo = 'y2mate_kKZFjgX.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/oh-no-no-no_x52qaxB.mp3'; Arquivo = 'oh-no-no-no_x52qaxB.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/sudden-suspense.mp3'; Arquivo = 'sudden-suspense.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/sound-effect-suspense-strike.mp3'; Arquivo = 'sound-effect-suspense-strike.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/dun_dun_dun.mp3'; Arquivo = 'dun_dun_dun.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/illuminati-confirmed-sound-effect-hd-audio.mp3'; Arquivo = 'illuminati-confirmed-sound-effect-hd-audio.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/suspense-drums.mp3'; Arquivo = 'suspense-drums.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/psycho-violin-screech.mp3'; Arquivo = 'psycho-violin-screech.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/vinheta-faustao-errou-rede-globo.mp3'; Arquivo = 'vinheta-faustao-errou-rede-globo.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/acertou-faustao.mp3'; Arquivo = 'acertou-faustao.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/uou-efeito-sonoro.mp3'; Arquivo = 'uou-efeito-sonoro.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/yeehaw-do-cowboy.mp3'; Arquivo = 'yeehaw-do-cowboy.mp3' }
  [PSCustomObject]@{ Url = 'https://www.myinstants.com/media/sounds/erro-do-windows.mp3'; Arquivo = 'erro-do-windows.mp3' }
)
foreach ($item in $arquivos) {
  $saida = Join-Path $destino $item.Arquivo
  Write-Host "Baixando $($item.Arquivo)..."
  Invoke-WebRequest -Uri $item.Url -OutFile $saida
}
Write-Host 'Concluído. Arquivos baixados na pasta trilhas.'